

  <!-- Left side column. contains the logo and sidebar -->

  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->

    <section class="sidebar">

     

      

      <!-- sidebar menu: : style can be found in sidebar.less -->

      <ul class="sidebar-menu" data-widget="tree">

        <li>

          <a href="<?php echo base_url() ?>admin/category">

            <i class="fa fa-edit"></i> <span>Category</span>

          </a>     

        </li>

        <li>

          <a href="<?php echo base_url() ?>admin/profile">

            <i class="fa fa-edit"></i> <span>Profile Posts</span>

          </a>     

        </li> 

        <li>

          <a href="<?php echo base_url() ?>admin/services">

            <i class="fa fa-edit"></i> <span>Services</span>

          </a>     

        </li>


        <li>

          <a href="<?php echo base_url() ?>admin/slide_img">

            <i class="fa fa-edit"></i> <span>Slider Profile Images</span>

          </a>     

        </li> 
        
        <li>

          <a href="<?php echo base_url() ?>admin/states">

            <i class="fa fa-edit"></i> <span>States</span>

          </a>     

        </li>  

        <li>

          <a href="<?php echo base_url() ?>admin/pro_types">

            <i class="fa fa-edit"></i> <span>Profile Types</span>

          </a>     

        </li>  


        <li>

          <a href="<?php echo base_url() ?>Admin/blog">

            <i class="fa fa-edit"></i> <span>Blog</span>

          </a>     

        </li>  



        <li>

          <a href="<?php echo base_url() ?>admin/location">

            <i class="fa fa-edit"></i> <span>Location</span>

          </a>     

        </li>



         <li>

          <a href="<?php echo base_url() ?>admin/videos">

            <i class="fa fa-edit"></i> <span>Videos</span>

          </a>     

        </li>
 
         <li>

          <a href="<?php echo base_url() ?>admin/reviews">

            <i class="fa fa-edit"></i> <span>Reviews</span>

          </a>     

        </li> 

        <!-- <li>

          <a href="<?php echo base_url() ?>Services/list">

            <i class="fa fa-edit"></i> <span>Services</span>

          </a>     

        </li> -->



        <li>

          <a href="<?php echo base_url() ?>admin/pages">

            <i class="fa fa-edit"></i>Pages<span></span>

          </a>     

        </li>



        <li>

          <a href="<?php echo base_url() ?>admin/meta">

            <i class="fa fa-edit"></i>Meta Tags<span></span>

          </a>     

        </li>   

    </section>

    <!-- /.sidebar -->

  </aside>